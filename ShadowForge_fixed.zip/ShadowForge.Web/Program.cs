using Microsoft.EntityFrameworkCore;
using Polly;
using Polly.Extensions.Http;
using ShadowForge.Core.Interfaces;
using ShadowForge.Data;
using ShadowForge.Data.Repositories;
using ShadowForge.Services;
using ShadowForge.Services.Network;
using ShadowForge.Services.ThreatIntel;
using ShadowForge.Services.UserGen;
using ShadowForge.Web.Hubs;

var builder = WebApplication.CreateBuilder(args);

// ── Blazor Server + SignalR ────────────────────────────────────────────────────
builder.Services.AddRazorComponents().AddInteractiveServerComponents();
builder.Services.AddSignalR();

// ── EF Core (SQLite for portability — swap connection string for Postgres) ────
builder.Services.AddDbContext<ShadowForgeDbContext>(options =>
    options.UseSqlite(builder.Configuration.GetConnectionString("Default")
        ?? "Data Source=shadowforge.db"));

// ── Repositories ──────────────────────────────────────────────────────────────
builder.Services.AddScoped<SessionRepository>();
builder.Services.AddScoped<EventRepository>();

// ── Polly resilience policies ──────────────────────────────────────────────────
// Retry 3 times with exponential backoff — handles free API tier rate limits
var retryPolicy = HttpPolicyExtensions
    .HandleTransientHttpError()
    .WaitAndRetryAsync(3, attempt => TimeSpan.FromSeconds(Math.Pow(2, attempt)),
        onRetry: (outcome, delay, attempt, ctx) =>
        {
            var logger = ctx.GetLogger();
            logger?.LogWarning("HTTP retry {Attempt} after {Delay}s — {Reason}",
                attempt, delay.TotalSeconds, outcome.Exception?.Message ?? outcome.Result.StatusCode.ToString());
        });

// ── HttpClientFactory with named clients ──────────────────────────────────────
builder.Services.AddHttpClient("OTX", client =>
{
    client.BaseAddress = new Uri("https://otx.alienvault.com/");
    client.DefaultRequestHeaders.Add("X-OTX-API-KEY",
        builder.Configuration["ApiKeys:OTX"] ?? "YOUR_OTX_KEY_HERE");
    client.Timeout = TimeSpan.FromSeconds(15);
}).AddPolicyHandler(retryPolicy);

builder.Services.AddHttpClient("AbuseIPDB", client =>
{
    client.BaseAddress = new Uri("https://api.abuseipdb.com/");
    client.DefaultRequestHeaders.Add("Key",
        builder.Configuration["ApiKeys:AbuseIPDB"] ?? "YOUR_ABUSEIPDB_KEY_HERE");
    client.DefaultRequestHeaders.Add("Accept", "application/json");
    client.Timeout = TimeSpan.FromSeconds(10);
}).AddPolicyHandler(retryPolicy);

builder.Services.AddHttpClient("RandomUser", client =>
{
    client.BaseAddress = new Uri("https://randomuser.me/");
    client.Timeout = TimeSpan.FromSeconds(10);
}).AddPolicyHandler(retryPolicy);

// ── Application services (scoped for Blazor — new instance per circuit) ───────
builder.Services.AddScoped<IThreatIntelService, ThreatIntelService>();
builder.Services.AddScoped<IUserGenService, UserGenService>();
builder.Services.AddScoped<INetworkSimService, NetworkSimService>();

// ── Simulation modules (transient — fresh state per execution) ────────────────
builder.Services.AddTransient<ReconModule>();
builder.Services.AddTransient<LateralMovementModule>();
builder.Services.AddTransient<PersistenceModule>();
builder.Services.AddTransient<ReportModule>();

// ── Orchestrator and registry (scoped to circuit) ────────────────────────────
builder.Services.AddScoped<ModuleRegistry>();
builder.Services.AddScoped<SimulationOrchestrator>();

// ── Web dashboard services ─────────────────────────────────────────────────────
builder.Services.AddScoped<ShadowForge.Web.Services.DashboardStateService>();

var app = builder.Build();

// ── Migrate database on startup ────────────────────────────────────────────────
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ShadowForgeDbContext>();
    await db.Database.EnsureCreatedAsync();
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();
app.UseAntiforgery();

app.MapRazorComponents<ShadowForge.Web.Components.App>().AddInteractiveServerRenderMode();
app.MapHub<SimulationHub>("/hubs/simulation");

app.Run();
